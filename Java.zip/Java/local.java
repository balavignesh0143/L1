class local
{
	public static void main(String args[])
	{
		String name="Bala";
		System.out.println(name);
	}
}