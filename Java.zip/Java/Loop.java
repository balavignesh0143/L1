class Loop
{
	public static void main(String args[])
	{
		int no=10;
		while(no>1)
		{
			no--;
			System.out.println(no);
		}
	}
}