class Employee
{
	public static void main(String args[])
	{
		int empId=Integer.parseInt(args[0]);
		String empName=args[1];
		int empAge=Integer.parseInt(args[2]);
		String empDesignation=args[3]
		int empSal=Integer.parseInt(args[4]);
		String empAddress=args[5];
		System.out.println("Employee ID:"+empId);
		System.out.println("Employee Name:"+empName);
		System.out.println("Employee Age:"+empAge);
		System.out.println("Employee Designation:"+empDesignation);
		System.out.println("Employee Salary:"+empSal);
		System.out.println("Employee Address:"+empAddress);
	}
}