class Condition
{
	public static void main(String args[])
	{
		int age=18;
		if(age>=18)
		{
			System.out.println("Eligible for vote!!!");
		}
		else
		{
			System.out.println("Not an eligible for vote");
		}
	}
}