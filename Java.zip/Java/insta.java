package instance.stat;

class Insta
{
	int empId=111;
	String empName="Bala";
	static String empOrg="Capgemini";	
	void display()
	{
		System.out.println("EmployeeID:"+empId);
		System.out.println("EmployeeName:"+empName);
	}
	static void display1()
	{
		System.out.println("EmployeeOrganization:"+empOrg);
	}
	public static void main(String args[])
	{
		Insta in=new Insta();
		in.display();
		Insta.display1();
	}
}