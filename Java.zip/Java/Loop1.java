class Loop1
{
	public static void main(String args[])
	{
		int num=20;
		do
		{
			num=num-2;
			System.out.println(num);
		}
		while(num>1);
	}
}