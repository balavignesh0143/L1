class Login
{
	public static void main(String args[])
	{
		String userName=args[0];
		String password=args[1];
		if(userName.equals("capgemini")&&password.equals("capgemini123"))
		{
			System.out.println("Login Success");
		}
		else
		{
			System.out.println("Invalid");
		}
	}
}